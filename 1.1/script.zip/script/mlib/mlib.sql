-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2023 at 05:04 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mlib4`
--

-- --------------------------------------------------------

--
-- Table structure for table `tx_import`
--

CREATE TABLE `tx_import` (
  `id` int(11) NOT NULL,
  `title` varchar(5000) NOT NULL,
  `content` varchar(5000) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tx_import`
--

INSERT INTO `tx_import` (`id`, `title`, `content`, `time`) VALUES
(2, 'Full URL for multiple lines', '%%surl%% \r\n', 1420712613),
(3, 'Non image files as downloads', '&lt;p class=&quot;demo-download&quot;&gt;&lt;img xsrc=&quot;%%thumb%%&quot; /&gt; &lt;b&gt;%%title%% (%%fullsize%%, %%type%% file)&lt;/b&gt; &lt;a href=&quot;%%url%%&quot;&gt;DOWNLOAD&lt;/a&gt;&lt;/p&gt;', 1420714475),
(6, 'thumbs', '&lt;a href=&quot;%%url%%&quot; target=&quot;_blank&quot;&gt;&lt;img xsrc=&quot;%%thumb%%&quot; /&gt;&lt;/a&gt;', 1420784828),
(8, 'Full img tag', '&lt;img xsrc=&quot;%%url%%&quot;&gt;', 1421235450),
(9, 'Thumbnail img tag', '&lt;img xsrc=&quot;%%thumb%%&quot;&gt;', 1421494938),
(10, 'Complete Info', '&lt;img xsrc=&quot;%%thumb%%&quot;&gt;&lt;h4&gt;%%title%% &lt;a target=&quot;_blank&quot; href=&quot;%%url%%&quot;&gt;DOWNLOAD&lt;/a&gt; [%%fullsize%%]&lt;/h4&gt;\r\n&lt;b&gt;Uploaded on&lt;/b&gt; : %%date%%&lt;br&gt;\r\n&lt;b&gt;Filetype&lt;/b&gt; : %%type%%&lt;br&gt;\r\n&lt;b&gt;Caption&lt;/b&gt; : %%caption%%&lt;br&gt;&lt;br&gt;', 1688003395);

-- --------------------------------------------------------

--
-- Table structure for table `tx_uploads`
--

CREATE TABLE `tx_uploads` (
  `id` varchar(500) NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(500) NOT NULL,
  `caption` varchar(5000) NOT NULL,
  `url` varchar(5000) NOT NULL,
  `thumb` varchar(5000) NOT NULL,
  `time` int(11) NOT NULL,
  `uid` varchar(1000) NOT NULL,
  `size` int(20) NOT NULL DEFAULT 0,
  `folder` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tx_import`
--
ALTER TABLE `tx_import`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tx_uploads`
--
ALTER TABLE `tx_uploads`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tx_import`
--
ALTER TABLE `tx_import`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
