/* Path to the folder where mlib folder exists */
main_domain = 'http://localhost/mlib4/';


mlib_domain = main_domain+'mlib/mlib-includes/';

/* Include required JS/CSS Files asynchronously to improve server response time of web-pages and reduce hassle */
var mlib_includes = '<script src="'+mlib_domain+'dropzone/dropzone.min.js" type="text/javascript"></script>\
<script src="'+mlib_domain+'pagination/jquery.simplePagination.js" type="text/javascript"></script>\
<script src="'+mlib_domain+'js/mlib.js" type="text/javascript"></script>\
<link href="'+mlib_domain+'css/mlib.css" rel="stylesheet" type="text/css" />\
<link href="'+mlib_domain+'dropzone/css/basic.css" rel="stylesheet" type="text/css" />\
<link href="'+mlib_domain+'dropzone/css/dropzone.min.css" rel="stylesheet" type="text/css" />\
<link href="'+mlib_domain+'pagination/simplePagination.css" rel="stylesheet" type="text/css" />';
document.write(mlib_includes);