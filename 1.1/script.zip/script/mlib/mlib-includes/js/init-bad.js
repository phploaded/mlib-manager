main_domain = 'http://localhost/mlib4/';
mlib_domain = main_domain+'mlib/mlib-includes/';

if(!window.jQuery){
var script = document.createElement('script');
script.type = "text/javascript";
script.src = mlib_domain+'js/jquery-3.7.0.min.js';
document.getElementsByTagName('head')[0].appendChild(script);
}

(function() {
      function getScript(url,success){
        var script=document.createElement('script');
        script.src=url;
        var head=document.getElementsByTagName('head')[0],
            done=false;
        script.onload=script.onreadystatechange = function(){
          if ( !done && (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete') ) {
            done=true;
            success();
            script.onload = script.onreadystatechange = null;
            head.removeChild(script);
          }
        };
        head.appendChild(script);
      }




getScript(mlib_domain+'dropzone/dropzone.min.js', function(){
getScript(mlib_domain+'pagination/jquery.simplePagination.js', function(){
getScript(mlib_domain+'js/loadCSS.js', function(){
getScript(main_domain+'demo.js', function(){
getScript(mlib_domain+'js/mlib.js', function(){
loadCSS(mlib_domain+'css/mlib.css');
loadCSS(mlib_domain+'dropzone/css/basic.css');
loadCSS(mlib_domain+'dropzone/css/dropzone.min.css');
loadCSS(mlib_domain+'pagination/simplePagination.css');
loadCSS(main_domain+'demo.css');
});
});
});
});
});
})();
